package com.example.kiosk_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
