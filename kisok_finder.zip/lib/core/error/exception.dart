class ServerException implements Exception {}

class EmptyCacheException implements Exception {}

class OfflineException implements Exception {}
