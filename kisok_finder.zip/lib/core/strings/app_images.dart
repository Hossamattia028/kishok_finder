class AppImages{

  static const  String images = "assets/image";
  static const  String icons = "assets/icon";
  


}