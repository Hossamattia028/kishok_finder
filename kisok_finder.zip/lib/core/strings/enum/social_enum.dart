// ignore_for_file: constant_identifier_names

enum SocialEnum{
  PHONE,
  FACEBOOK,
  GOOGLE,
  APPLE,
}