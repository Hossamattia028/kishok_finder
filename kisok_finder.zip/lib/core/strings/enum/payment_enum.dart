// ignore_for_file: constant_identifier_names

enum PaymentEnum{
  CASH,
  PAYFORT,
  TAMARA,
  AMWAL,
  TABBY
}