// ignore_for_file: constant_identifier_names

enum PackageEnum {
  UNLIMITED,
  JUST_ONCE
}


enum PackageCategory {
  EXTERNAL,
  INTERNAL
}