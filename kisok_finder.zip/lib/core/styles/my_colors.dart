import 'package:flutter/material.dart';


const kPrimaryBlack = Color(0xff00273f);
const kSecondPrimary = kTextGrey;
const kRed = Color(0xffC91E2F);

const kPrimary = Color(0xffC91E2F);
const kHomeSearchBack = Color(0xffF2F4FC);
const kWhite = Colors.white;
const kBlack= Colors.black;
const kDark= Color(0xff1A1A1A);
const kBlack2 = Color(0xff333333);
const kConfirmed = Color(0xffAC737B);
const kChart = Color(0xffBCACF3);

const kFreeColor = Color(0xff3d9cd2);


const kBackGroundN = Color(0xfff3f4f8);

const kTextGrey = Color(0xff98A2B3);
const kTextPrimagryLight = Color(0xffDC6803);

const kBackGroundBlue = Color(0xffE0F2FE);
const kTextBlue = Color(0xff0086C9);

const kTextBackGround = Color(0xffEAECF0);

const kYellowLight = Color(0xffFEF0C7);

const kBlackBackGround = Color(0xff28282B);
const kGreyTextBckground = Color(0xffF2F4F7);


const kBackGround = Color(0xffEEEEEE);
const containerBackGround = Color(0xffE4E4E7);

const kTamaraColor = Color(0xfff78c9e);
const kTabbyColor = Color(0xff3bffa0);




//profile section
const kBlackProfileLines = Color(0xff101828);
const kBlackProfileLineIcon = Color(0xff475467);

const kBackGroundLanguage = Color(0xffF4F4F5);








const kText1 = Color(0xff27272E);
const kText2 = Color(0xff333333);
const kHint = Color(0xff635858);
const kBackGreenColor = Color(0xff5CCD6B);
const kBackBlueColor = Color(0xff4069D7);
const kBackYellowColor = Color(0xffFFCB6D);
const kBackPurpleColor = Color(0xff6600FF);


