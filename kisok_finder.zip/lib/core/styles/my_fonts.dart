


var primaryFontReg  = "Helvetica"; 
var primaryFontBold  = "Helvetica"; 
var primaryFontSemiBold  = "Helvetica"; 
